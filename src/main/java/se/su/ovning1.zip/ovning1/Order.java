package se.su.ovning1;

public class Order {

    private final long orderNumber;
    private static final long counter;
    private final List<Item> items;

    public Order(List<Item> items){
        this.items = items;
    }

    public String getReceipt(){
        return n;
    }


    public double getTotalValuePlusVAT(){
        double totalValue;

        for(Item i : items){
            totalValue += i.getPriceWithVAT();
        }

        return totalValue;

    }

    public double getTotalValue(){
        double totalValue;

        for(Item i : items){
            totalValue += getTotalValue();
        }

        return totalValue;

    }


}
